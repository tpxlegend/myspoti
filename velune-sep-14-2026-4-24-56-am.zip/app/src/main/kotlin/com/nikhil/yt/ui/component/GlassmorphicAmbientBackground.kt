package com.nikhil.yt.ui.component

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun GlassmorphicAmbientBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_glow")

    val glowOffset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow1"
    )

    val glowOffset2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(16000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow2"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF080516), // Deep midnight violet
                        Color(0xFF0E0A24),
                        Color(0xFF140E30)  // Sleek vibrant glassmorphism canvas
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Orb 1: Soft glowing vibrant purple (Top-Right)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x998B5CF6), // Vibrant purple center glow
                        Color(0x557C4DFF),
                        Color.Transparent
                    ),
                    center = Offset(
                        x = width * (0.75f + 0.08f * glowOffset1),
                        y = height * (0.18f + 0.06f * glowOffset2)
                    ),
                    radius = width * 0.85f
                )
            )

            // Orb 2: Soft glowing electric blue (Center-Left)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x883D5AFE), // Electric blue glow
                        Color(0x442563EB),
                        Color.Transparent
                    ),
                    center = Offset(
                        x = width * (0.18f - 0.06f * glowOffset2),
                        y = height * (0.52f + 0.08f * glowOffset1)
                    ),
                    radius = width * 0.75f
                )
            )

            // Orb 3: Soft glowing neon cyan / violet lighting (Bottom-Right)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x6600E5FF), // Neon cyan glow accent
                        Color(0x33651FFF),
                        Color.Transparent
                    ),
                    center = Offset(
                        x = width * (0.82f - 0.04f * glowOffset1),
                        y = height * (0.82f - 0.06f * glowOffset2)
                    ),
                    radius = width * 0.65f
                )
            )

            // Subtly frosted glass light reflection sheen across canvas
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x0EFFFFFF),
                        Color(0x03000000),
                        Color(0x0E80D8FF)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(width, height)
                )
            )
        }

        content()
    }
}

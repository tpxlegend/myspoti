package com.nikhil.yt.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    borderWidth: Dp = 1.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val glassFill = Brush.linearGradient(
        colors = listOf(
            Color(0x3F261852), // Semi-transparent frosted purple glass
            Color(0x2E1A0F3C)
        )
    )

    val luminousBorder = Brush.linearGradient(
        colors = listOf(
            Color(0x60B388FF), // Glowing vibrant purple border accent
            Color(0x403D5AFE), // Electric blue
            Color(0x4D00E5FF)  // Glowing cyan highlight
        )
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(glassFill)
            .border(width = borderWidth, brush = luminousBorder, shape = shape)
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        content = content
    )
}

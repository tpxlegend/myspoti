package com.nikhil.yt.playback

import com.nikhil.yt.constants.AudioQuality
import com.nikhil.yt.innertube.YouTube
import com.nikhil.yt.innertube.models.response.PlayerResponse
import com.nikhil.yt.utils.YTPlayerUtils.PlaybackData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * JioSaavn API client and stream resolver based on https://github.com/cyberboysumanjay/JioSaavnAPI
 * Provides high-quality (up to 320kbps) audio streams and metadata.
 */
object JioSaavnPlaybackSource {
    private const val TAG = "JioSaavnPlaybackSource"
    private const val DES_KEY = "38346591"
    private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    private val streamCache = ConcurrentHashMap<String, Pair<String, Long>>()

    data class SaavnSong(
        val id: String,
        val title: String,
        val artist: String,
        val album: String?,
        val durationSeconds: Int,
        val thumbnailUrl: String?,
        val encryptedMediaUrl: String?,
        val decryptedMediaUrl: String?,
    )

    /**
     * Decrypts encrypted media URL using DES/ECB/PKCS5Padding with key "38346591"
     */
    fun decryptMediaUrl(encryptedUrl: String): String? {
        return runCatching {
            val keyBytes = DES_KEY.toByteArray(Charsets.UTF_8)
            val keySpec = SecretKeySpec(keyBytes, "DES")
            val cipher = Cipher.getInstance("DES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, keySpec)
            val decoded = Base64.getDecoder().decode(encryptedUrl.trim())
            val decrypted = cipher.doFinal(decoded)
            String(decrypted, Charsets.UTF_8)
        }.onFailure {
            Timber.tag(TAG).e(it, "Failed to decrypt JioSaavn media URL")
        }.getOrNull()
    }

    /**
     * Formats the media URL for the target audio quality (320kbps, 160kbps, 96kbps).
     */
    fun formatMediaUrlForQuality(baseStreamUrl: String, quality: AudioQuality = AudioQuality.HIGHEST): String {
        val targetSuffix = when (quality) {
            AudioQuality.HIGHEST -> "_320.mp4"
            AudioQuality.HIGH -> "_320.mp4"
            AudioQuality.AUTO -> "_160.mp4"
            AudioQuality.LOW -> "_96.mp4"
        }
        return baseStreamUrl
            .replace("_96.mp4", targetSuffix)
            .replace("_160.mp4", targetSuffix)
            .replace("_320.mp4", targetSuffix)
    }

    /**
     * Clean up common titles (remove terms like Official Video, Remix, HD, brackets, etc.)
     */
    private fun cleanTitleForSearch(title: String): String {
        return title
            .replace(Regex("(?i)\\b(official|music|video|audio|lyric|lyrics|hd|4k|remix|ft\\.|feat\\.)\\b"), "")
            .replace(Regex("[()\\[\\]\\-_]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Searches JioSaavn for songs matching a query across primary API and mirror endpoint.
     */
    suspend fun searchSongs(query: String, limit: Int = 10): List<SaavnSong> = withContext(Dispatchers.IO) {
        val primaryResults = searchSongsPrimary(query, limit)
        if (primaryResults.isNotEmpty()) return@withContext primaryResults
        searchSongsMirror(query, limit)
    }

    private fun searchSongsPrimary(query: String, limit: Int): List<SaavnSong> {
        return runCatching {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val urlString = "https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=$limit&p=1&q=$encodedQuery"
            val jsonString = httpGet(urlString) ?: return@runCatching emptyList()

            val root = JSONObject(jsonString)
            val results = root.optJSONArray("results") ?: return@runCatching emptyList()
            val list = mutableListOf<SaavnSong>()

            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val title = cleanHtmlEntities(item.optString("title"))
                val subtitle = cleanHtmlEntities(item.optString("subtitle"))
                val moreInfo = item.optJSONObject("more_info")
                val image = item.optString("image").replace("150x150", "500x500")
                val duration = moreInfo?.optString("duration")?.toIntOrNull() ?: 0
                val encryptedMediaUrl = moreInfo?.optString("encrypted_media_url")
                val album = cleanHtmlEntities(moreInfo?.optString("album").orEmpty())

                val decryptedUrl = encryptedMediaUrl?.takeIf { it.isNotBlank() }?.let { decryptMediaUrl(it) }

                list.add(
                    SaavnSong(
                        id = id,
                        title = title,
                        artist = subtitle,
                        album = album,
                        durationSeconds = duration,
                        thumbnailUrl = image,
                        encryptedMediaUrl = encryptedMediaUrl,
                        decryptedMediaUrl = decryptedUrl,
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }

    private fun searchSongsMirror(query: String, limit: Int): List<SaavnSong> {
        return runCatching {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val urlString = "https://saavn.dev/api/search/songs?query=$encodedQuery&limit=$limit"
            val jsonString = httpGet(urlString) ?: return@runCatching emptyList()

            val root = JSONObject(jsonString)
            val data = root.optJSONObject("data")
            val results = data?.optJSONArray("results") ?: return@runCatching emptyList()
            val list = mutableListOf<SaavnSong>()

            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val title = cleanHtmlEntities(item.optString("name"))
                val artistsObj = item.optJSONObject("artists")
                val primaryArtists = artistsObj?.optJSONArray("primary")
                val artistName = primaryArtists?.optJSONObject(0)?.optString("name").orEmpty()

                val albumObj = item.optJSONObject("album")
                val albumName = albumObj?.optString("name").orEmpty()
                val duration = item.optInt("duration", 0)

                val downloadUrlArray = item.optJSONArray("downloadUrl")
                var decryptedUrl: String? = null
                if (downloadUrlArray != null && downloadUrlArray.length() > 0) {
                    val lastDownload = downloadUrlArray.optJSONObject(downloadUrlArray.length() - 1)
                    decryptedUrl = lastDownload?.optString("url")
                }

                val imageArray = item.optJSONArray("image")
                val imageUrl = imageArray?.optJSONObject(imageArray.length() - 1)?.optString("url")

                if (!decryptedUrl.isNullOrBlank()) {
                    list.add(
                        SaavnSong(
                            id = id,
                            title = title,
                            artist = artistName,
                            album = albumName,
                            durationSeconds = duration,
                            thumbnailUrl = imageUrl,
                            encryptedMediaUrl = null,
                            decryptedMediaUrl = decryptedUrl,
                        )
                    )
                }
            }
            list
        }.getOrDefault(emptyList())
    }

    /**
     * Resolves song details and decrypted stream URL for a given JioSaavn song ID.
     */
    suspend fun getSongDetails(songId: String): SaavnSong? = withContext(Dispatchers.IO) {
        runCatching {
            val urlString = "https://www.jiosaavn.com/api.php?__call=song.getDetails&cc=in&_marker=0%3F_marker%3D0&_format=json&pids=$songId"
            val jsonString = httpGet(urlString) ?: return@runCatching null

            val root = JSONObject(jsonString)
            val songObj = root.optJSONObject(songId) ?: return@runCatching null

            val id = songObj.optString("id")
            val title = cleanHtmlEntities(songObj.optString("song"))
            val subtitle = cleanHtmlEntities(songObj.optString("primary_artists"))
            val moreInfo = songObj.optJSONObject("more_info")
            val image = songObj.optString("image").replace("150x150", "500x500")
            val duration = moreInfo?.optString("duration")?.toIntOrNull() ?: 0
            val encryptedMediaUrl = moreInfo?.optString("encrypted_media_url")
            val album = cleanHtmlEntities(moreInfo?.optString("album").orEmpty())

            val decryptedUrl = encryptedMediaUrl?.takeIf { it.isNotBlank() }?.let { decryptMediaUrl(it) }

            SaavnSong(
                id = id,
                title = title,
                artist = subtitle,
                album = album,
                durationSeconds = duration,
                thumbnailUrl = image,
                encryptedMediaUrl = encryptedMediaUrl,
                decryptedMediaUrl = decryptedUrl,
            )
        }.getOrNull()
    }

    /**
     * Primary resolver for playback streaming data using JioSaavn.
     */
    suspend fun resolvePlayback(
        queryOrId: String,
        hintTitle: String? = null,
        hintArtist: String? = null,
        audioQuality: AudioQuality = AudioQuality.HIGHEST
    ): PlaybackData? = withContext(Dispatchers.IO) {
        val cached = streamCache[queryOrId]
        if (cached != null && cached.second > System.currentTimeMillis()) {
            return@withContext createPlaybackData(queryOrId, cached.first, hintTitle, hintArtist)
        }

        // 1. If query is a JioSaavn song ID
        var song: SaavnSong? = if (queryOrId.length in 6..12 && !queryOrId.contains(" ")) {
            getSongDetails(queryOrId)
        } else null

        // 2. Otherwise search by title / artist / query
        if (song?.decryptedMediaUrl == null) {
            var effectiveTitle = hintTitle?.takeIf { it.isNotBlank() }
            var effectiveArtist = hintArtist?.takeIf { it.isNotBlank() }

            if (effectiveTitle == null) {
                val mediaInfo = runCatching { YouTube.getMediaInfo(queryOrId).getOrNull() }.getOrNull()
                if (mediaInfo != null && !mediaInfo.title.isNullOrBlank()) {
                    effectiveTitle = mediaInfo.title
                    effectiveArtist = mediaInfo.author
                }
            }

            val candidates = mutableListOf<String>()
            if (!effectiveTitle.isNullOrBlank() && !effectiveArtist.isNullOrBlank()) {
                candidates.add("$effectiveTitle $effectiveArtist")
            }
            if (!effectiveTitle.isNullOrBlank()) {
                candidates.add(effectiveTitle)
                val cleaned = cleanTitleForSearch(effectiveTitle)
                if (cleaned.isNotBlank() && cleaned != effectiveTitle) {
                    candidates.add(cleaned)
                }
            }
            if (queryOrId.any { it.isLetter() }) {
                candidates.add(queryOrId)
            }

            for (candidate in candidates.distinct()) {
                val searchResults = searchSongs(candidate, limit = 5)
                song = searchResults.firstOrNull { it.decryptedMediaUrl != null }
                if (song != null) break
            }
        }

        val decryptedUrl = song?.decryptedMediaUrl ?: return@withContext null
        val finalStreamUrl = formatMediaUrlForQuality(decryptedUrl, audioQuality)

        // Cache stream URL for 6 hours
        streamCache[queryOrId] = finalStreamUrl to (System.currentTimeMillis() + 6 * 3600 * 1000L)

        return@withContext createPlaybackData(
            mediaId = queryOrId,
            streamUrl = finalStreamUrl,
            title = song.title.ifBlank { hintTitle },
            artist = song.artist.ifBlank { hintArtist },
            durationSeconds = song.durationSeconds,
            thumbnailUrl = song.thumbnailUrl
        )
    }

    private fun createPlaybackData(
        mediaId: String,
        streamUrl: String,
        title: String? = null,
        artist: String? = null,
        durationSeconds: Int = 0,
        thumbnailUrl: String? = null
    ): PlaybackData {
        val bitrate = if (streamUrl.contains("_320")) 320000 else if (streamUrl.contains("_160")) 160000 else 96000
        val format = PlayerResponse.StreamingData.Format(
            itag = 140,
            url = streamUrl,
            mimeType = "audio/mp4; codecs=\"mp4a.40.2\"",
            bitrate = bitrate,
            width = null,
            height = null,
            contentLength = null,
            quality = "hd",
            fps = null,
            qualityLabel = null,
            averageBitrate = bitrate,
            audioQuality = "AUDIO_QUALITY_HIGH",
            approxDurationMs = (durationSeconds * 1000L).takeIf { it > 0 }?.toString(),
            audioSampleRate = 44100,
            audioChannels = 2,
            loudnessDb = null,
            lastModified = null,
            signatureCipher = null,
            cipher = null
        )

        val videoDetails = PlayerResponse.VideoDetails(
            videoId = mediaId,
            title = title ?: "Track",
            author = artist ?: "Unknown",
            channelId = "",
            lengthSeconds = durationSeconds.toString(),
            musicVideoType = null,
            viewCount = "0",
            thumbnail = com.nikhil.yt.innertube.models.Thumbnails(
                if (thumbnailUrl != null) listOf(
                    com.nikhil.yt.innertube.models.Thumbnail(
                        url = thumbnailUrl,
                        width = 500,
                        height = 500
                    )
                ) else emptyList()
            )
        )

        return PlaybackData(
            audioConfig = null,
            videoDetails = videoDetails,
            playbackTracking = null,
            format = format,
            streamUrl = streamUrl,
            streamExpiresInSeconds = 21600
        )
    }

    private fun httpGet(urlStr: String): String? {
        return runCatching {
            val url = URL(urlStr)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            val sb = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                sb.append(line)
            }
            reader.close()
            sb.toString()
        }.onFailure {
            Timber.tag(TAG).e(it, "HTTP GET failed for: $urlStr")
        }.getOrNull()
    }

    private fun cleanHtmlEntities(text: String): String {
        return text
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("&#039;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
    }
}

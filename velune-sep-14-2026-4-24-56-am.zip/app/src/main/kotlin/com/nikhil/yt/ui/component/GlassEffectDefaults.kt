package com.nikhil.yt.ui.component

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class GlassSurfaceStyle(
    val surfaceTint: Color,
    val surfaceAlpha: Float,
    val overlayColor: Color,
    val overlayAlpha: Float,
    val blurRadius: Dp,
    val useVibrancy: Boolean,
    val useLens: Boolean,
    val lensHeight: Dp,
    val lensAmount: Dp,
    val borderColor: Color,
    val borderAlpha: Float,
    val backgroundDimAlpha: Float,
    val backgroundDimColor: Color,
)

object GlassEffectDefaults {

    val NavigationBarDark = GlassSurfaceStyle(
        surfaceTint = Color(0xFF1D123D),
        surfaceAlpha = 0.50f,
        overlayColor = Color(0xFF3D5AFE),
        overlayAlpha = 0.18f,
        blurRadius = 48.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 22.dp,
        lensAmount = 42.dp,
        borderColor = Color(0xFFB388FF),
        borderAlpha = 0.28f,
        backgroundDimAlpha = 0.25f,
        backgroundDimColor = Color(0xFF0D0822),
    )

    val NavigationBarLight = GlassSurfaceStyle(
        surfaceTint = Color(0xFF31235B),
        surfaceAlpha = 0.45f,
        overlayColor = Color(0xFF7C4DFF),
        overlayAlpha = 0.20f,
        blurRadius = 52.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 22.dp,
        lensAmount = 42.dp,
        borderColor = Color(0xFFB388FF),
        borderAlpha = 0.35f,
        backgroundDimAlpha = 0.20f,
        backgroundDimColor = Color(0xFF0D0822),
    )

    val NavigationBarPureBlack = GlassSurfaceStyle(
        surfaceTint = Color(0xFF140D2B),
        surfaceAlpha = 0.65f,
        overlayColor = Color(0xFF2A1B54),
        overlayAlpha = 0.35f,
        blurRadius = 44.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 16.dp,
        lensAmount = 32.dp,
        borderColor = Color(0xFFB388FF),
        borderAlpha = 0.22f,
        backgroundDimAlpha = 0.45f,
        backgroundDimColor = Color(0xFF080516),
    )

    val MiniPlayerDark = GlassSurfaceStyle(
        surfaceTint = Color(0xFF1E1342),
        surfaceAlpha = 0.52f,
        overlayColor = Color(0xFF3D5AFE),
        overlayAlpha = 0.20f,
        blurRadius = 44.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 22.dp,
        lensAmount = 42.dp,
        borderColor = Color(0xFFB388FF),
        borderAlpha = 0.30f,
        backgroundDimAlpha = 0.22f,
        backgroundDimColor = Color(0xFF0D0822),
    )

    val MiniPlayerLight = GlassSurfaceStyle(
        surfaceTint = Color(0xFF2E1C59),
        surfaceAlpha = 0.48f,
        overlayColor = Color(0xFF7C4DFF),
        overlayAlpha = 0.22f,
        blurRadius = 48.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 22.dp,
        lensAmount = 42.dp,
        borderColor = Color(0xFF80D8FF),
        borderAlpha = 0.32f,
        backgroundDimAlpha = 0.18f,
        backgroundDimColor = Color(0xFF0D0822),
    )

    val MiniPlayerPureBlack = GlassSurfaceStyle(
        surfaceTint = Color(0xFF140D2E),
        surfaceAlpha = 0.62f,
        overlayColor = Color(0xFF2B1A52),
        overlayAlpha = 0.32f,
        blurRadius = 38.dp,
        useVibrancy = true,
        useLens = true,
        lensHeight = 18.dp,
        lensAmount = 34.dp,
        borderColor = Color(0xFFB388FF),
        borderAlpha = 0.25f,
        backgroundDimAlpha = 0.42f,
        backgroundDimColor = Color(0xFF080516),
    )

    fun navigationBarStyle(isDark: Boolean, isPureBlack: Boolean): GlassSurfaceStyle {
        return when {
            isPureBlack -> NavigationBarPureBlack
            isDark -> NavigationBarDark
            else -> NavigationBarLight
        }
    }

    fun miniPlayerStyle(isDark: Boolean, isPureBlack: Boolean): GlassSurfaceStyle {
        return when {
            isPureBlack -> MiniPlayerPureBlack
            isDark -> MiniPlayerDark
            else -> MiniPlayerLight
        }
    }
}
